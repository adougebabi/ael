import importlib,json,pathlib,py_compile
values=[]
for name in ['one','two']:
 path=pathlib.Path('module_'+name+'.py')
 if not path.exists():continue
 py_compile.compile(str(path),doraise=True)
 values.append(importlib.import_module('module_'+name).value())
pathlib.Path('build').mkdir(exist_ok=True)
pathlib.Path('build/data.js').write_text('window.fixtureValues='+json.dumps(values)+';')
print(json.dumps({'compiled':len(values),'sum':sum(values)}))
