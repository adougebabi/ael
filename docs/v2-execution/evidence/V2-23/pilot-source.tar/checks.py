import importlib,sys
name=sys.argv[1]
module=importlib.import_module('module_'+name)
assert module.value()=={'one':3,'two':5}[name]
print('checked '+name)
